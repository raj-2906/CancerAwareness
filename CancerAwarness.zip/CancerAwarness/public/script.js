document.getElementById("year").textContent = new Date().getFullYear();

async function loadQuote() {
  try {
    const res = await fetch("https://api.quotable.io/random");
    const data = await res.json();
    document.getElementById("quote").textContent = '"' + data.content + '"';
    document.getElementById("author").textContent = "— " + data.author;
  } catch {
    document.getElementById("quote").textContent = '"Stay strong. You are not alone."';
  }
}

document.getElementById("new-quote").addEventListener("click", loadQuote);
loadQuote();

document.getElementById("contact-form").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value;
  document.getElementById("feedback").textContent =
    "Thank you " + name + "! Your message has been received.";
});
